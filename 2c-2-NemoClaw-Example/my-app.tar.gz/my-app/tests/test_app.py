"""Tests for app.py.

Only the "/" route is covered right now. When the agent adds
/healthz, it should add a corresponding test here (or in a new
test module) as part of its SELF-REVIEW / test-policy step.
"""

import pytest

from app import app


@pytest.fixture()
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_index_returns_hello_message(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.get_json() == {"message": "Hello from my-app!"}
