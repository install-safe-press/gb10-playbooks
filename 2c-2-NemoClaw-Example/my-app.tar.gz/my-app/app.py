"""
A tiny Flask app used as a test project for the NemoClaw
Software Development Agent recipe.

Intentionally minimal: only a "/" route exists right now.
The classic first feature request to try with the agent is:

    "Add a /healthz endpoint that returns
     {status: 'ok', commit: <git sha>} with a test."
"""

from flask import Flask, jsonify

app = Flask(__name__)


@app.route("/")
def index():
    """Basic landing route so the app has something to serve."""
    return jsonify({"message": "Hello from my-app!"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
