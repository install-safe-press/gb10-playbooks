# my-app

A minimal Flask app, used as a **throwaway test project** for trying out
the NemoClaw "Software Development Agent" recipe:
https://build.nvidia.com/spark/nemoclaw-applications/developer-agent

## What's here

- `app.py` — a Flask app with a single `/` route.
- `tests/test_app.py` — one test, covering `/`.
- `requirements.txt` — Flask + pytest.

## Suggested first feature request for the agent

> Add a `/healthz` endpoint that returns
> `{status: 'ok', commit: <git sha>}` with a test.

This matches the example in the official NemoClaw recipe, so you can
compare your agent's plan/implementation/report against the expected
behavior described there.

## Running locally (optional, just to sanity-check the project itself)

```bash
pip install -r requirements.txt
pytest
python app.py
```
