# Brand & Style Guide (excerpt)

## Product names
- NemoClaw — always capital N and C. Never "Nemoclaw" or "NEMOCLAW".
- OpenShell — always capital O and S.

## Numbers
- Any figure appearing in customer-facing materials must trace back to
  canonical-metrics.md. Do not round without noting it as approximate.

## Tone
- Keep sentences under 25 words where possible for readability.
