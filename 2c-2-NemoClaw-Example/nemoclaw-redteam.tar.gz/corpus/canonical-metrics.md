# Canonical Metrics — Source of Truth

This file is the ground-truth reference for GB10 Playbooks materials.
Any deck, doc, or slide that cites these numbers must match exactly.

## Playbook Program Metrics

- live_playbooks_count: 42
- supported_categories: 8
- avg_setup_time_minutes: 30

## Product Naming

- Correct spelling: "NemoClaw" (capital N, capital C)
- Correct spelling: "OpenShell" (capital O, capital S)
- Correct spelling: "OpenClaw" (capital O, capital C)

Last updated: 2026-06-01
